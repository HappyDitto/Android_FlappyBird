#  Flappy Bird

Simple flappy bird app for android. Has an AI mode and tells you a random fact about your score at the end of the game using data from http://numbersapi.com

Made the initial game at the start of winter break for fun and then modified for final school project.
